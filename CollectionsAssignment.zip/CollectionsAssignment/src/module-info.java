/**
 * 
 */
/**
 * @author buddredd
 *
 */
module CollectionsAssignment {
}