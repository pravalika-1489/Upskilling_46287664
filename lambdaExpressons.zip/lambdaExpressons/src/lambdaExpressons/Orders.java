package lambdaExpressons;
//import java.util.function.Predicate;
import java.util.ArrayList;

class Orders {
	int id;
	double price;
	String status;
	
Orders(int id,double price,String status){
	this.id=id;
	this.price=price;
	this.status=status;
 }
}

