/**
 * 
 */
/**
 * @author buddredd
 *
 */
module lambdaExpressons {
}