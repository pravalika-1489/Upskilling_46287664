/**
 * 
 */
/**
 * @author buddredd
 *
 */
module ExpHandAssignment {
}